import { runCliCommand } from '../run-cli.js';

function makePlatform({ textSpec = 'Name\nBob', shouldThrowRead = false } = {}) {
  const writes = [];
  const out = [];
  const err = [];
  return {
    writes,
    out,
    err,
    async readText() {
      if (shouldThrowRead) {
        throw new Error('missing file');
      }
      return textSpec;
    },
    async writeText(path, content) {
      writes.push({ path, content });
    },
    createLineWriter() {
      const lines = [];
      return {
        async writeLine(line) {
          lines.push(line);
        },
        async close() {
          writes.push({ path: 'stream', content: lines.join('\n') });
        },
      };
    },
    stdout(text) {
      out.push(text);
    },
    stderr(text) {
      err.push(text);
    },
  };
}

test('returns error when input file cannot be read', async () => {
  const platform = makePlatform({ shouldThrowRead: true });
  const code = await runCliCommand({
    platform,
    options: {
      inputFile: 'missing.txt',
      outputFile: null,
      format: 'csv',
      rowCount: 1,
      testMode: false,
      showProgress: false,
      shouldStream: false,
      unsafeFakerExpressions: false,
      pairwise: false,
    },
  });
  expect(code).toBe(1);
  expect(platform.err.join('')).toContain('Unable to read input file');
});

test('writes output file in buffered mode', async () => {
  const platform = makePlatform();
  const code = await runCliCommand({
    platform,
    options: {
      inputFile: 'spec.txt',
      outputFile: 'out.csv',
      format: 'csv',
      rowCount: 2,
      testMode: false,
      showProgress: false,
      shouldStream: false,
      unsafeFakerExpressions: false,
      pairwise: false,
    },
  });
  expect(code).toBe(0);
  expect(platform.writes.length).toBe(1);
  expect(platform.writes[0].path).toBe('out.csv');
});

test('returns error when stream writer fails', async () => {
  const platform = makePlatform();
  platform.createLineWriter = () => ({
    async writeLine() {
      throw new Error('disk full');
    },
    async close() {},
  });

  const code = await runCliCommand({
    platform,
    options: {
      inputFile: 'spec.txt',
      outputFile: 'out.csv',
      format: 'csv',
      rowCount: 2,
      testMode: false,
      showProgress: false,
      shouldStream: true,
      unsafeFakerExpressions: false,
      pairwise: false,
    },
  });

  expect(code).toBe(1);
  expect(platform.err.join('')).toContain('Streaming generation failed');
});

test('ignores stream mode when pairwise is requested', async () => {
  const platform = makePlatform({ textSpec: 'Browser\nChrome,Firefox,Safari\nTheme\nLight,Dark' });
  const code = await runCliCommand({
    platform,
    options: {
      inputFile: 'spec.txt',
      outputFile: 'out.csv',
      format: 'csv',
      rowCount: 2,
      testMode: false,
      showProgress: false,
      shouldStream: true,
      unsafeFakerExpressions: false,
      pairwise: true,
    },
  });
  expect(code).toBe(0);
  expect(platform.err.join('')).toBe('');
  expect(platform.writes.length).toBe(1);
  expect(platform.writes[0].path).toBe('out.csv');
});

test('reports warning in test mode when stream mode is ignored for pairwise', async () => {
  const platform = makePlatform({ textSpec: 'Browser\nChrome,Firefox,Safari\nTheme\nLight,Dark' });
  const code = await runCliCommand({
    platform,
    options: {
      inputFile: 'spec.txt',
      outputFile: 'out.csv',
      format: 'csv',
      rowCount: 2,
      testMode: true,
      showProgress: true,
      shouldStream: true,
      unsafeFakerExpressions: false,
      pairwise: true,
    },
  });
  expect(code).toBe(0);
  expect(platform.out.join('')).toContain('WARNING: Streaming is ignored when pairwise generation is enabled');
  expect(platform.out.join('')).toContain('WARNING: rowCount is ignored when pairwise generation is enabled.');
});

test('generates deterministic pairwise output in buffered mode', async () => {
  const platform = makePlatform({ textSpec: 'Browser\nChrome,Firefox,Safari\nTheme\nLight,Dark' });
  const code = await runCliCommand({
    platform,
    options: {
      inputFile: 'spec.txt',
      outputFile: null,
      format: 'json',
      rowCount: 100,
      testMode: false,
      showProgress: false,
      shouldStream: false,
      unsafeFakerExpressions: false,
      pairwise: true,
    },
  });

  expect(code).toBe(0);
  const rendered = platform.out.join('').trim();
  expect(JSON.parse(rendered)).toEqual([
    { Browser: 'Chrome', Theme: 'Light' },
    { Browser: 'Chrome', Theme: 'Dark' },
    { Browser: 'Firefox', Theme: 'Light' },
    { Browser: 'Firefox', Theme: 'Dark' },
    { Browser: 'Safari', Theme: 'Light' },
    { Browser: 'Safari', Theme: 'Dark' },
  ]);
});

test('supports comments and blank lines in input schema', async () => {
  const platform = makePlatform({
    textSpec: '# comment\n\nPriority\nenum(high,medium,low)\n\nStatus\nenum(active,inactive,pending)',
  });
  const code = await runCliCommand({
    platform,
    options: {
      inputFile: 'spec.txt',
      outputFile: null,
      format: 'json',
      rowCount: 2,
      testMode: false,
      showProgress: false,
      shouldStream: false,
      unsafeFakerExpressions: false,
      pairwise: false,
    },
  });
  expect(code).toBe(0);
  const parsed = JSON.parse(platform.out.join('').trim());
  expect(parsed).toHaveLength(2);
  expect(Object.keys(parsed[0])).toEqual(['Priority', 'Status']);
});

test('amend mode updates only first N rows and keeps full output', async () => {
  const platform = makePlatform({ textSpec: 'Name\nBob' });
  platform.readText = async (file) => {
    if (file === 'schema.txt') return 'Name\nBob';
    if (file === 'data.csv') return '"Name"\n"Alice"\n"Eve"';
    throw new Error('missing');
  };
  const code = await runCliCommand({
    platform,
    options: {
      command: 'amend',
      inputFile: 'schema.txt',
      dataFile: 'data.csv',
      inputFormat: 'csv',
      outputFile: null,
      format: 'json',
      rowCount: 1,
      testMode: false,
      showProgress: false,
      shouldStream: true,
      unsafeFakerExpressions: false,
      pairwise: false,
    },
  });
  expect(code).toBe(0);
  expect(JSON.parse(platform.out.join('').trim())).toEqual([{ Name: 'Bob' }, { Name: 'Eve' }]);
});

test('accepts uppercase format names via shared normalization', async () => {
  const platform = makePlatform();
  const code = await runCliCommand({
    platform,
    options: {
      inputFile: 'spec.txt',
      outputFile: null,
      format: 'CSV',
      rowCount: 1,
      testMode: false,
      showProgress: false,
      shouldStream: false,
      unsafeFakerExpressions: false,
      pairwise: false,
    },
  });
  expect(code).toBe(0);
  expect(platform.err.join('')).toBe('');
});
