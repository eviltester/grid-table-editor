/**
 * Shared utility for parsing enum rule specifications
 * Handles both simple comma-separated and function-based enum formats
 */
export class EnumParser {
  /**
   * Check if rule spec uses AWD enum function format
   * @param {string} ruleSpec - The rule specification to check
   * @returns {boolean} True if using function format
   */
  static isAwdEnumFormat(ruleSpec) {
    return /^(enum|datatype\.enum|awd\.datatype\.enum)\s*\(/.test(ruleSpec);
  }

  /**
   * Extract enum values from rule specification
   * Handles both formats:
   * - Simple: "value1,value2,value3"
   * - Function: enum("value1","value2","value3") or enum(value1,value2,value3)
   * @param {string} ruleSpec - The rule specification to parse
   * @returns {string[]} Array of enum values
   */
  static extractEnumValues(ruleSpec) {
    const spec = String(ruleSpec || '').trim();

    // Check if it's a formal enum function format
    if (this.isAwdEnumFormat(spec)) {
      return this.extractAwdEnumValues(spec);
    }

    // Simple comma-separated format
    return spec.split(',').map((v) => v.trim());
  }

  /**
   * Extract values from formal enum function formats
   * Handles: enum(value1,value2) and enum("value1", "value2", "value3")
   * @param {string} ruleSpec - The function-format rule specification
   * @returns {string[]} Array of enum values
   */
  static extractAwdEnumValues(ruleSpec) {
    // Match patterns like: enum(value1,value2) or enum("value1", "value2", "value3")
    const match = ruleSpec.match(/^(?:enum|datatype\.enum|awd\.datatype\.enum)\s*\(\s*(.+)\s*\)$/);
    if (!match) {
      throw new Error('Invalid enum format');
    }

    const paramsStr = match[1].trim();
    const values = [];
    let currentValue = '';
    let inQuotes = false;
    let i = 0;

    while (i < paramsStr.length) {
      const char = paramsStr[i];

      if (char === '"' && (i === 0 || paramsStr[i - 1] !== '\\')) {
        // Toggle quote state for unescaped quotes
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        // Found separator outside quotes
        if (currentValue.trim().length > 0) {
          values.push(currentValue.trim());
        }
        currentValue = '';
      } else {
        // Add character to current value
        currentValue += char;
      }
      i++;
    }

    // Add final value
    if (currentValue.trim().length > 0) {
      values.push(currentValue.trim());
    }

    if (values.length === 0) {
      throw new Error('No valid values found in enum');
    }

    // Remove surrounding quotes from quoted values
    return values.map((value) => {
      const trimmed = value.trim();
      if (trimmed.startsWith('"') && trimmed.endsWith('"') && trimmed.length >= 2) {
        return trimmed.slice(1, -1);
      }
      return trimmed;
    });
  }
}
